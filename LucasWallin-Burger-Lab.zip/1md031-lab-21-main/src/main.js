//UNCOMMENT THE BELOW LINES WHEN YOU REACH TO THE VUE PART OF THE TUTORIAL


import { createApp } from 'vue'
import App from './App.vue'
import router from './router'

createApp(App).use(router).mount('#app')

